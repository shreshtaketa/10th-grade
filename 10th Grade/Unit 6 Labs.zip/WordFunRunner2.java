//(c) A+ Computer Science
//www.apluscompsci.com

//Name - Shreshta Keta
//Date - 11/13/18
//Class - 
//Lab  - EXTRA CREDIT LAB

// Lab Chapter 6 - #8  WordFun2    2018

// Uses files WordFun2.java and WordFunRunner2.java

import static java.lang.System.*;

public class WordFunRunner2
{
	public static void main( String args[] )
	{
		
		out.println("Lab Chapter 6 - #8  WordFun2 EXTRA CREDIT    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
	    System.out.println( WordFun2.moveEmAround("apluscompsci",3) );
		System.out.println( WordFun2.moveEmAround("apluscompsci",5) );
		System.out.println( WordFun2.moveEmAround("apluscompsci",1) );
		System.out.println( WordFun2.moveEmAround("apluscompsci",2) );
		System.out.println( WordFun2.moveEmAround("apluscompsci",30) );
		System.out.println( WordFun2.moveEmAround("apluscompsci",4) );	   
	}
}