//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/8/2018
//Class -
//Lab  - 

import static java.lang.System.*;


// Lab Chapter 6 - #2  StringEquality    2018

// Uses files StringEqualityRunner.java and StringEquality.java


public class StringEqualityRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 6 - #2  StringEquality    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		
		// create a new StringEquality object and send
		// to the constructor the values  "hello" and  "goodbye" 
	    StringEquality test = new StringEquality("hello","goodbye");
	   
	    out.println(test);  // this calls the toString() method
			// skips a line	
		
		
		// add more test cases (see the docs for the data values)
		// call your set method. Do not make more objects
		
		test.setWords("one","two");
		out.println(test);
		
		
		test.setWords("four","four");
		out.println(test);
		
		
		test.setWords("TCEA","UIL");
		out.println(test);
		
		
		test.setWords("State","Champions");
		out.println(test);
		
		
		test.setWords("ABC","ABC");
		out.println(test);
		
		
		test.setWords("ABC","CBA");
		out.println(test);
		
		
		test.setWords("Same","Same");
		out.println(test);
		
	}
}