//(c) A+ Computer Science
//www.apluscompsci.com

//Name - Shreshta Keta
//Date - 11/13/18
//Class - 
//Lab  - EXTRA CREDIT LAB

import static java.lang.System.*;

public class WordFun2
{
	public static String moveEmAround(String a, int x)
	{
		if (x < 12)
			return a.substring(x,a.length()) + a.substring(0,x);
		return "no can do";

		

	}
}