//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/8/2018
//Class -
//Lab  -

import static java.lang.System.*;

// EXTRA CREDIT LAB

// Lab Chapter 6 - #4  Social    2018

// Uses files SocialRunner.java and Social.java


public class SocialRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 6 - #4  Social 2018  EXTRA CREDIT LAB");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();	
			
		Social Test = new Social("456-56-234");
		out.println(test);
		// add test cases
		
		test.setWord("1-1-1");
		out.println(test);
		
		test.setWord("102-2-12");
		out.println(test);
		
		test.setWord("0-0-0");
		out.println(test);
	}
}