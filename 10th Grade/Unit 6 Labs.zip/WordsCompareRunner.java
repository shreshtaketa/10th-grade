//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/8/2018
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 6 - #3  WordsCompare    2018

// Uses files WordsCompareRunner.java and WordsCompare.java


public class WordsCompareRunner
{
   public static void main( String args[] )
   {
		out.println("Lab Chapter 6 - #3  WordsCompare    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		// this should create a new WordsCompare object and sends
		// the values "abe" and "ape" to the constructor
		// these values will be stored inside the object  
	    WordsCompare test = new WordsCompare("abe", "ape");
	   
	    out.println(test);  // this calls the toString() method
	    out.println();
   	
   	
		// add more test cases (see the docs)
		// call your set method
		
		test.setWords("giraffe","gorilla");
		out.println(test);
		
		test.setWords("one","two");
		out.println(test);
		
		test.setWords("fun","funny");
		out.println(test);
		
		test.setWords("123","19");
		out.println(test);
		
		test.setWords("193","1910");
		out.println(test);
		
		test.setWords("goofy","godfather");
		out.println(test);
		
		test.setWords("funnel","fun");
		out.println(test);

   }
}