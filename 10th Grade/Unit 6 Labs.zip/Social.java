//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/8/2018
//Class -
//Lab  - 

//Social and SocialRunner EXTRA CREDIT
import static java.lang.System.*;

public class Social
{
   private String socialNum;
   private int sum;

	public Social()
	{
		socialNum = "";
	}

	public Social(String soc)
	{
		socialNum = soc;
	}


	public void setWord(String w)
	{
		socialNum = w;
	}

	public void chopAndAdd()
	{
		sum = socialNum.substring(0,socialNum.indexOf("-")) + socialNum.substring(socialNum.lastIndexOf("-")) + socialNum.substring(socialNum.indexOf("-")+1,socialNum.lastIndexOf("-"));

	}

	public String toString()
	{
		return "SS# " + socialNum + " has a total of " + sum + "\n";
	}
}