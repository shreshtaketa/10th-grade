//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 3/15/19
//Class - 
//Lab  -

import static java.lang.System.*;
import java.lang.Math;
import java.util.Arrays;

// Lab Chapter 17 - #5  EXTRA CREDIT ArrayOfPrimes    2019

// Uses files ArrayOfPrimesRunner.java and ArrayOfPrimes.java


public class ArrayOfPrimesRunner
{

	public static void main( String args[] )
	{
		System.out.println("Lab Chapter 17 - #5  ArrayOfPrimes Extra Credit  2019");
		System.out.println();
		System.out.println();
		
		// ***** fill in your name
		System.out.println("My name is Shreshta Keta");
		System.out.println();		
		System.out.println();		




	   out.println("The 1st 5 primes starting from 2 are :: \n"+Arrays.toString(ArrayOfPrimes.getPrimeList(5)));   
	   out.println();
	   
	   // add more test cases   

		out.println("The 1st 5 primes starting from 10 are :: \n"+Arrays.toString(ArrayOfPrimes.getPrimeList(5,10)));   
	   out.println();
	   
	   out.println("The 1st 10 primes starting from 100 are :: \n"+Arrays.toString(ArrayOfPrimes.getPrimeList(10,100)));   
	   out.println();




		System.out.println();
		System.out.println(); 
	   
	}
}