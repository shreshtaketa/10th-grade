//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 1/11/2018
//Class -
//Lab  -


// CHAPTER 10 Lab #3 - Extra Credit - 110 points - 2018-2019

import java.util.Scanner;
import static java.lang.System.*;

public class RPSRunner
{
	public static void main(String args[])
	{
		out.println("Lab Chapter 10 - #3 EXTRA CREDIT  RockPaperScissors  2018-2019");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		Scanner keyboard = new Scanner(System.in);
		char response;
		
		//add in a do while loop after you get the basics up and running
		do
			{
		
			String player = "";
			
			out.println();
			
			out.print("Rock-Paper-Scissors - pick your weapon[R,P,S] :: ");
			player = keyboard.next();
			
			//read in the player value
			RockPaperScissors game = new RockPaperScissors(player);
			System.out.println(game.toString());
			
			out.println();
			out.print("Do you want to play again? ");
			response = keyboard.next().charAt(0);
			
			} while (response == 'y');
	}
}



