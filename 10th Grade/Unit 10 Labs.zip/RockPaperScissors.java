//� A+ Computer Science  -  www.apluscompsci.com - 2018-2019
//Name - Shreshta Keta
//Date - 1/11/2018
//Class -
//Lab  - EXTRA CREDIT LAB 

import java.util.Scanner;
import static java.lang.System.*;
import java.util.Random;

public class RockPaperScissors
{
	private String playChoice;
	private String compChoice;
	
	public RockPaperScissors()
	{
		playChoice = "";
		compChoice = "";
	}

	public RockPaperScissors(String player)
	{
		playChoice = player;
		setPlayers(player);
	}

	public void setPlayers(String player)
	{
		playChoice = player;
		compChoice = "";
		int num = (int) Math.random()*3;
		switch (num)
		{
			case 0 : compChoice = "R"; break;
			case 1 : compChoice = "P"; break;
			case 2 : compChoice = "S"; break;
		}

	}

	public String determineWinner(String playChoice, String compChoice)
	{
	
		String winner="";
		
		if (compChoice.equals("R"))
		{
			compChoice = "R";
			if (playChoice.equals("S"))
				winner = "!Computer wins <<Rock Breaks Scissors>>!";
			else if (playChoice.equals("P"))
				winner = "!Player wins <<Paper Covers Rock>>!";
			else if (playChoice.equals("R"))
				winner = "!Draw Game!";
		}
		else if (compChoice.equals("P"))
		{
			compChoice = "P";
			if (playChoice.equals("S"))
				winner = "!Player wins <<Scissors Cuts Paper>>!";
			else if (playChoice.equals("R"))
				winner = "!Computer wins <<Paper Covers Rock>>!";
			else if (playChoice.equals("P"))
				winner = "!Draw Game!";
		}
		else if (compChoice.equals("S"))
		{
			compChoice = "S";
			if (playChoice.equals("R"))
				winner = "!Player wins <<Rock Breaks Scissors>>!";
			else if (playChoice.equals("P"))
				winner = "!Computer wins <<Scissors Cuts Paper>>!";
			else if (playChoice.equals("S"))
				winner = "!Draw Game!";
		}
		
		return winner;
	}


	public String toString()
	{
		String output =  "\n" + "player had " + playChoice + "\n" + "computer had " + compChoice + "\n" + determineWinner(playChoice, compChoice);
		return output;
	}
}