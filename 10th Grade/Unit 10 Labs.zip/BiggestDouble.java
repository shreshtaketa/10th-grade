//� A+ Computer Science  -  www.apluscompsci.com - 2018-2019
//Name -
//Date -  
//Class -
//Lab  -

import static java.lang.System.*;

public class BiggestDouble
{
	private double one,two,three,four;

	public BiggestDouble()
	{
		this(0,0,0,0);  // using this calls our own init constructor
	}

	public BiggestDouble(double a, double b, double c, double d)
	{
		one = a;
		two = b;
		three = c;
		four = d;
	}

	public void setDoubles(double a, double b, double c, double d)
	{
		one = a;
		two = b;
		three = c;
		four= d;
	}

	public double getBiggest() // You need multiple if statements here (if one>two && one>three && etc.)
	{
		{
			if (one > two && one > three && one > four)
				return one;
			else if (two > one && two > three && two > 4)
				return two;
			else if (three > one && three > two && three > four)
				return three;
			else if (four > one && four > two && four > three)
				return four;
		}
		
		return 0;
	}
	
	

	public String toString()
	{
	   return one + " " + two + " " + three + " " + four;  // replace the " " with your instance variables. Concatenate them with " " in between
	}
}