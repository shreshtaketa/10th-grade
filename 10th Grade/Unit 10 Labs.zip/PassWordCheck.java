//� A+ Computer Science  -  www.apluscompsci.com - 2018-2019
//Name - Shreshta Keta
//Date - 1/8/2019
//Class -
//Lab  -

import java.util.Scanner;
import static java.lang.System.*;

class PassWordCheck
{
	private String realPassword;

	public PassWordCheck(String pass)  // initialization constructor
	{
		realPassword = pass;
	}

	public void check() // this is where all the code will go
	{
		Scanner keyboard = new Scanner(System.in);
		boolean passwordCorrect = false;  // this is your boolean variable!
		
		// start your do...while loop here
		do
		{
			
		// prompt the user to enter a password
		// see StringRunner lab from Chapter 5 to review how to read in a one word input. Save your input in a String variable
		
		out.print("Enter the password :: ");
		String pass = keyboard.next();
		
		// if the input password equals the realPassword (How do you check equality of Strings?)
		// set your boolean variable equal to true 
		// and print "VALID". You will need { } here
		// else, print "INVALID"
		
		if (pass.equals(realPassword))
		{
			
			passwordCorrect=true;
			out.println("VALID");
			
		}
		else
		{
			passwordCorrect=false;
			out.println("INVALID");
		}
		
		
		
		
		}while(passwordCorrect == false);  // continue so long as boolean variable is false
		
		
	}
}