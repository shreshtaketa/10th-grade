//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/31/18
//Class -
//Lab  -

import static java.lang.System.*;
import java.util.Scanner;

// Lab Chapter 5 - #3  StringOddOrEven    2018



public class StringRunner
{
	public static void main ( String[] args )
	{
		out.println("Lab Chapter 5 - #3  StringOddOrEven    2018");
		out.println();
		out.println();
		// fill in your name
		out.println("My name is Shreshta Keta");
		out.println();


		// create a new Scanner object and pass it System.in
		// this object knows how to read in data from the keyboard
		// variable keyboard holds the location of the Scanner object in memory
		Scanner keyboard = new Scanner (System.in);
		
		// we now prompt the user to enter a word
		out.print("Enter a word :: ");
		
		// and now we read in the String and store it in a String variable
		// and NO it is not keyboard.nextString()!
		// there is NO nextString() method NO NO NO NO NO
		String strWord = keyboard.nextLine(); 
		
		// create a StringOddOrEven object and pass to the constructor the
		//     value of strWord
		StringOddOrEven obj = new StringOddOrEven(strWord);
		
		
		// print out the value of the toString() method
		out.println(obj.toString());
		
		out.println(); // print a blank line
		
		
		// add more cases
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 

		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 

		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 
		
		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 
		
		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 
		
		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 
		
		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
		out.print("Enter a word :: ");
		strWord = keyboard.nextLine(); 

		obj.setString(strWord);
		out.println(obj.toString());
		out.println();
		
		
	}
}