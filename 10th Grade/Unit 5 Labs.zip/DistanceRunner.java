//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date -  11/6/18
//Class -
//Lab  -

import java.util.Scanner;
import static java.lang.System.*;
import static java.lang.Math.*;

// Lab Chapter 5 - #5  Distance    2018

// Uses files  DistanceRunner.java and Distance.java

public class DistanceRunner
{
	public static void main( String[] args )
	{

		out.println("Lab Chapter 5 - #5  Distance    2018");
		out.println();
		out.println();
		// fill in your name
		out.println("My name is Shreshta Keta");
		out.println();

		// create a new Scanner object
		Scanner keyboard = new Scanner( System.in );


		out.print("Enter X1 :: ");
		int xOne = keyboard.nextInt();
		
		out.print("Enter Y1 :: ");
		int yOne = keyboard.nextInt();
		
		out.print("Enter X2 :: ");
		int xTwo = keyboard.nextInt();
		
		out.print("Enter Y2 :: ");
		int yTwo = keyboard.nextInt();

		// create a new Distance object (call the default constructor)
		Distance test = new Distance();
		test.setCoordinates(xOne, yOne, xTwo, yTwo);
		out.println(test.determineClosest());
		
		// add more test cases

		out.print("Enter X1 :: ");
		xOne = keyboard.nextInt();
		
		out.print("Enter Y1 :: ");
		yOne = keyboard.nextInt();
		
		out.print("Enter X2 :: ");
		xTwo = keyboard.nextInt();
		
		out.print("Enter Y2 :: ");
		yTwo = keyboard.nextInt();
		
		test.setCoordinates(xOne, yOne, xTwo, yTwo);
		out.println(test.determineClosest());
		
		
		
		out.print("Enter X1 :: ");
		xOne = keyboard.nextInt();
		
		out.print("Enter Y1 :: ");
		yOne = keyboard.nextInt();
		
		out.print("Enter X2 :: ");
		xTwo = keyboard.nextInt();
		
		out.print("Enter Y2 :: ");
		yTwo = keyboard.nextInt();
		
		test.setCoordinates(xOne, yOne, xTwo, yTwo);
		out.println(test.determineClosest());
		
		
		
		out.print("Enter X1 :: ");
		xOne = keyboard.nextInt();
		
		out.print("Enter Y1 :: ");
		yOne = keyboard.nextInt();
		
		out.print("Enter X2 :: ");
		xTwo = keyboard.nextInt();
		
		out.print("Enter Y2 :: ");
		yTwo = keyboard.nextInt();
		
		test.setCoordinates(xOne, yOne, xTwo, yTwo);
		out.println(test.determineClosest());
		
	}
}