//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta
//Date - Keta
//Class -
//Lab  - EXTRA CREDIT 2018

import static java.lang.System.*;

public class StringChecker
{
	private String word;

	public StringChecker()
	{
		word = "";
	}

	public StringChecker(String s)
	{
		word = s;
	}

   public void setString(String s)
   {
   		word = s;
   }

	public boolean findLetter(char c)//false is just a placeholder. Change it!
	{
		return name.indexOf(char c);
	}

	public boolean findSubString(String s) // false is just a placeholder. Change it!
	{
		return 
	}

 	public String toString()
 	{
 		return word + "\n\n";
	}
}