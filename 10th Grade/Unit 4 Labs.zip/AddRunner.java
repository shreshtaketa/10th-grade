//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/22/18
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 4 - #1 - AddStrings    2018


public class AddRunner
{
	public static void main ( String[] args )
	{
		System.out.println("Lab Chapter 4 - #1 - AddStrings    2018");
		System.out.println();
		System.out.println("My name is Shreshta Keta");
		System.out.println();
		System.out.println();
		
		// here we create a new AddStrings object and we send the
		// values "hello"  and "world" to the constructor
		// reference variable demo is assigned the memory address (location) of 
		//  the AddStrings object 	
			
		AddStrings demo = new AddStrings("hello","world");
		demo.add(); // calls the add() method
		out.println(demo); // calls the toString() method
		
		// calls the setStrings method and passes the
		//    values "jim" and "bob"
		
		demo.setStrings("jim","bob");	
		demo.add();  // calls the add() method
		out.println(demo);  // calls the toString() method
		
		// add more test cases
		
		demo.setStrings("sally","sue");	
		demo.add();
		out.println(demo);  
			
		demo.setStrings("computer","science");	
		demo.add();
		out.println(demo);  
			
		demo.setStrings("uil","contests");	
		demo.add();
		out.println(demo);  
			
		
		// look at the doc file to see the test case values
		
		
				
	}
}