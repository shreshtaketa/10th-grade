//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/22/18
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 4 - #2 - FirstAndLast    2018

public class FirstRunner
{
	public static void main ( String[] args )
	{
		
		System.out.println("Lab Chapter 4 - #2 - FirstAndLast    2018");
		System.out.println();
		System.out.println("My name is Shreshta Keta");
		System.out.println();
		System.out.println();

		// here we create a new FirstAndLast object and we send the
		//    value "hello" to the constructor
		// reference variable demo is assigned the memory address (location) of 
		//    the FirstAndLast object 	
			
		FirstAndLast demo = new FirstAndLast("Hello");
		demo.findFirstLastLetters(); // calls method findFirstLastLetters();
		out.println(demo); // calls the toString()
		
		

		// add more test cases	
		
		demo.setString("World");
		demo.findFirstLastLetters();
		out.println(demo);
		
		demo.setString("JukeBox");
		demo.findFirstLastLetters();
		out.println(demo);
		
		demo.setString("TCEA");
		demo.findFirstLastLetters();
		out.println(demo);
		
		demo.setString("UIL");
		demo.findFirstLastLetters();
		out.println(demo);
		
		// look at the doc file to see the test case values
		
	}
}