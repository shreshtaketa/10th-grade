//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 8/28/2018
//Class - AP Computer Science
//Lab  - AsciiBox

public class AsciiBox
{
	public static void main(String[] args)
	{
		System.out.println("name Shreshta Keta \t  date 08\\28\\2018 \n\n" );//replace name and date
		System.out.println("\n\nAsciiBox\n\n" ); //leave as is. 
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA");
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++++++++++++++++++++++++" );
		
		
		// add more println statements to finish the design






		System.out.println("AsciiBox  2018");//leave as is.
	}
}