//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 08/28/2018
//Class - AP Computer Science
//Lab  - AsciiBox2

public class AsciiBox2
{
	public static void main(String[] args)
	{
		System.out.println("name Shreshta Keta \t  date 08/28/2018 \n\n" );
		System.out.println("\n\nAsciiBox2\n\n" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA" );
		System.out.println("+++++++++++++++++++++++++" );
		System.out.println("+++                   +++" );
		System.out.println("+++                   +++" );
		System.out.println("+++                   +++" );
		System.out.println("+++        GO         +++" );
		System.out.println("+++     WEESTLAKE     +++" );
		System.out.println("+++       CHAPS       +++" );
		System.out.println("+++                   +++" );
		System.out.println("+++                   +++" );
		System.out.println("+++                   +++" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA" );
		System.out.println("+++++++++++++++++++++++++ ");
		
		// add more lines of code to println your Ascii Box 2








		System.out.println("AsciiBox2  2018"); // leave as is
	}
}