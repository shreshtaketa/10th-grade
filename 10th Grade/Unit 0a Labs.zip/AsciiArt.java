//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 08/31/2018
//Class - AP Computer Science
//Lab  - AsciiArt

public class AsciiArt
{
	public static void main ( String[] args )
	{
		System.out.println("Your Name Shreshta Keta \t Date 08/31/18 \t Period 4");
		System.out.println("\n\n The Heart");
		System.out.println("\n\nAsciiArt\n\n" );


		// write your instructions (statements, commands) below
		
		// you can replace this triangle shape with your own characters
		// to create your own design
		System.out.println("    ----  ----    " );
		System.out.println("   /    \\/    \\  " );
		System.out.println("   \\          /    " );
		System.out.println("    \\        /     ");
		System.out.println("     \\      /      ");
		System.out.println("      \\    /       ");
		System.out.println("       \\  /        ");
		System.out.println("        \\/         ");

		//add other output
		// the lines below are just reminders - do not delete them
		System.out.println(" \n\n\n\nHelpFul Hints" );
		System.out.println("\\\\ draws one backslash on the screen!\n" );
		System.out.println("\\\" draws one double quote on the screen!\n" );
		System.out.println("\\\' draws one single quote on the screen!\n\n\n" ); 
		System.out.println("Ascii Art 2018" ); // leave as is
	}
}