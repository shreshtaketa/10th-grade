//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/13/18
//Class -
//Lab  -

import static java.lang.System.*; 

// Lab Chapter 9 - #6  Perfect    2018

// Uses files PerfectRunner.java and Perfect.java


public class PerfectRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 9 - #6  Perfect    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		


		// STEP 1: **************************************************
		
		Perfect obj = new Perfect(496);
		out.println(obj.toString());
		out.println();
		
		
		
		
		// add more test cases
		
		obj.setNums(45);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(6);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(14);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(8128);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(1245);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(33);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(28);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(27);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(33550336);
		out.println(obj.toString());
		out.println();
		
															
	}
}