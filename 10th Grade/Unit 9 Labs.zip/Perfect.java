//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Ketya
//Date - 12/13/18
//Class -
//Lab  -

import static java.lang.System.*;

public class Perfect
{
	// instance variable 
    private int number;




    // add an initialization constructor
    // it should be marked with the accessor keyword  public
    // it has to have the same name as the class
    // and NO return type (not even void)
    // it needs to receive the beginning value for 
    //    the instance variable number
 	
	public Perfect(int num)
	{
		number = num;
	}


    // add a set method
    // it should be marked with the accessor keyword  public
	// it should be void, since we are NOT returning a value
    // it needs to receive a new value for 
    //    the instance variable number
	// it should be called  setNumber

	public void setNums(int num)
	{
		number = num;
	}
	
	

	public boolean isPerfect()
	{
		// a perfect number has all of its divisors except for itself add up
		//    to itself 
		// Examples:  6 is a perfect number since its divisors (1, 2, 3) add up to itself (6)
		//           28 is a perfect number since its divisors (1,2,4,7,14) add up to itself (28)
		 

		// loop through all of the possible divisors except for the
		//    number itself
		
		
		// STEP 1:
		// create an int variable called sum and assign it the value 0
		// 
		
		int sum = 0;

		// STEP 2:
		// create an int variable called divisor and assign it the value 1
		// 
		
		int divisor = 1;
		
		// STEP 2:
		// write the while loop condition 
		// while the divisor is less than or equal to  number divided by 2
		while (divisor  <=  number/2)
		{
			// STEP 3:
			// write an if statement
			// if number is divisible by the divisor (a little mod squad help is in order)
			//     add the divisor to your sum
			
			if (number % divisor == 0)
			{
				sum = divisor + sum;
			}
			
			// STEP 4:
			// add 1 to your divisor so that you can live to divide again (maybe)
			
			divisor++;
			
		}
		

		// should you return a true or a false value?
		// it gets rather iffy here
		// is your sum equal to your number?  If so, return true, otherwise return false
		
		if (sum == number)
			return true; 
		
		return false;
	}



	// add a toString() method
	// you will need an if statement  or  an if else statement
	// return number + " is perfect.";
	// or return number + " is NOT perfect.";
	
	public String toString()
	{
		if (isPerfect()==true)
			return number + " is perfect.";
		return number + " is NOT perfect.";
	}
	
		
	
}