//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/12/2018
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 9 - #5  Reverse Number    2018

// Uses files ReverseNumberRunner.java and ReverseNumber.java


public class ReverseNumberRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 9 - #5  ReverseNumber    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		


		// STEP 1: **************************************************
		// the methods inside the ReverseNumber class are NOT static
		//    therefore, you will need to create a ReverseNumber object 
		
		ReverseNumber obj = new ReverseNumber(234);
		
		
		
		// STEP 2: **************************************************
		// call your object's toString() method and print it
		
		out.println(obj.toString());
		
		
		
		// STEP 3: **************************************************
		// skip a line
		out.println();
		
		
		
		
		// add more test cases 
		// DO NOT CREATE MORE OBJECTS
		// Call your setNumber method to change the number inside
		//    your ReverseNumber object
		
		obj.setNums(10000);
		out.println(obj.toString());
		out.println();
		
		
		obj.setNums(111);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(9005);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(84645);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(8547);
		out.println(obj.toString());
		out.println();
		
		obj.setNums(123456789);
		out.println(obj.toString());
		out.println();
		
	}
}