//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/7/2018
//Class -
//Lab  -

import static java.lang.System.*;

public class DigitCounter
{
	
   // this static method will receive a number
   // you can call this static method from the runner file by using the name of
   // the class.method() 
   // Example:  DigitCounter.countDigits(234)
   
   public static int countDigits( int number )
	{
		int count=0;
		
		// use a while loop
		while (number > 0)
		{
			  // add 1 to the count
			  // divide by 10
			  count++;
			  number = number/10;
		}
		
		
		return count; 
	}
}