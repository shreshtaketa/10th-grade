//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/14/18
//Class -
//Lab  -

import static java.lang.System.*;

public class LetterRemover
{
	// instance variables (attributes, properties, fields)
    private String sentence;
    private char lookFor;


	// default constructor
	public LetterRemover()
	{
		// call the setter method with default values
		sentence = "";
		lookFor = ' ';
	}



	// add in a second constructor. It will be an initialization constructor
	// it should receive a beginning value for sentence and for lookFor
	
	public LetterRemover(String s, char rem)
	{
		sentence = s;
		lookFor = rem;
	}
	
	
	public void setRemover(String s, char rem)
	{
		sentence = s;
		lookFor = rem;
	}



	public String removeLetters()
	{
		String cleaned = sentence;
		
		
		// look at the String cleaned to see if it contains the lookFor character
		// use the String's  indexOf(lookFor) to find the position of the character 
		//    if it exists
		
		int pos = cleaned.indexOf(lookFor);
		
		while (pos >= 0 && pos < cleaned.length())
		{
			// get the substring to the left and right of the character position (pos)
			//    and get a new cleaned value 
			cleaned = cleaned.substring(0,pos) + cleaned.substring(pos + 1,cleaned.length());
			
			// now look for the character again and get its position (pos) in the String
			pos = cleaned.indexOf(lookFor);
			
		}
		
		return cleaned;
	}



	public String toString()
	{
		return sentence + " - letter to remove " + lookFor + "\n" + removeLetters();
	}
}