//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -
//EXTRA CREDIT 
import static java.lang.System.*;

class StringRemover
{
   private String sentence;
   private String remove;

	//add in default and initialization constructors
	

	public void setRemover(String s, String rem)
	{
	}

	public String removeStrings()
	{
		String cleaned = sentence;
		return cleaned;
	}

	public String toString()
	{
		return "";
	}
}