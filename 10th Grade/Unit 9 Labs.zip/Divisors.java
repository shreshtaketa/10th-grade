//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/11/2018
//Class -
//Lab  -

import static java.lang.System.*;

public class Divisors
{
	
	
	public static String getDivisors( int number )
	{
		String output = "";
		
		
		// loop through all of the possible divisors except for the
		//    number itself
		
		
		// STEP 1:
		// create an int variable called divisor and assign it the value 1
		// 
		
		int divisor = 1;
		
		// STEP 2:
		// write the while loop condition 
		// while the divisor is less than or equal to  number divided by 2
		while (divisor  <=  (number/2))
		{
			// STEP 3:
			// write an if statement
			// if number is divisible by the divisor? (a little mod squad help is in order)
			//     join divisor onto the right hand side of output and join on a space " "
			//     output = output + ??? + " ";
			
			if (number%divisor==0)
				output = output + divisor + " ";
			
			// STEP 4:
			// add 1 to your divisor so that you can live to divide again (maybe)
			
			divisor++;
			
		}
		
		
		
		return output; 
	}
	
	
}