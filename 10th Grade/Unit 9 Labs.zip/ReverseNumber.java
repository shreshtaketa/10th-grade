//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/12/2018
//Class -
//Lab  -

import static java.lang.System.*;

public class ReverseNumber
{
	// instance variable
    private int number;


    // add an initialization constructor
    // it should be marked with the accessor keyword  public
    // it has to have the same name as the class
    // and NO return type (not even void)
    // it will have one parameter that receives the beginning value for 
    //    the instance variable number
    
    public ReverseNumber(int num)
    {
    	number = num;
    }
    
	
	
    // add a set method
    // it should be marked with the accessor keyword  public
	// it should be void, since we are NOT returning a value
    // it will have the same code as the initialization constructor
	// it should be called  setNumber


	public void setNums(int num)
	{
		number = num;
	}
	
	// look at DigitAdder.java to see how you get one digit and 
	//chop off number
	public int getReverse()
	{
		int rev = 0;	

		while (number>0)
		{
			
			int digit = (int) ((double)number%10);
			rev = rev*10 + digit;
			number = number/10;
			
		}	
				
		return rev;
	}


	// *******************************************
	// add  a toString() method
	// look back at other labs to see how to write
	//    a toString() method
	
	public String toString()
	{
	
	return number + " reversed is " + getReverse(); 
	
	}



		
	
} // end marker for the class ReverseNumber

