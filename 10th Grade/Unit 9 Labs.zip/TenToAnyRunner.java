//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;


// Lab Chapter 9 - #8  TenToAny    2018

// Uses files TenToAnyRunner.java and TenToAny.java

// *******************************************
// EXTRA CREDIT
// *******************************************


public class TenToAnyRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 9 - #8  (Extra Credit) TenToAny    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is ????????  ????????????????");
		out.println();		
		out.println();		
		
		
		// add test cases	
		
	}
}