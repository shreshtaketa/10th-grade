//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/11/2018
//Class -
//Lab  -

import static java.lang.System.*; 

public class DigitAdder
{
   public static int sumDigits( int number )
	{
		int sum=0;
		
		// use a while loop
		// look at the doc file for help
		
		while (number > 0)
		{
			   int digit = number % 10;
			   // now add this digit value to your sum
			   sum = sum + digit;
			   // now strip the right most digit from number (use /10)
			   number = number / 10;
		}
		
		
		return sum;
	}
}