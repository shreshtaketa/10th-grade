//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/11/2018
//Class -
//Lab  -

import static java.lang.System.*;

public class DigitMath
{
	
   private static int countDigits( int number )
	{
		int count = 0;
		
		// look back at a previous lab for help
		
		while (number > 0)
		{
		
		count++;
		number = number/10;
		
		}
		
		return count;
	}


	private static int sumDigits( int number )
	{
		int sum=0;
		
		// look back at a previous lab for help

		while (number > 0)
		{
			   int digit = number % 10;
			   sum = sum + digit;
			   number = number / 10;
		}
		
		
		return sum;
	}


	public static double averageDigits( int number )
	{
		double average = 0.0;
		
		// you can call other static methods 
		// you do not need the name of the class
		
		// be careful, an int divided by an int truncates 
		//    your fractional part
		// both methods above return an int (and do not change it)
		//    a little casting may help you or multiply by 1.0
		
		average = (double) sumDigits(number)/ (double) countDigits(number);
		
		return average; // replace me with returning the average
	}
}