//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/13/18
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 9 - #7  LetterRemover    2018

// Uses files LetterRemoverRunner.java and LetterRemover.java


public class LetterRemoverRunner
{
	public static void main( String args[] )
	{
		// add test cases		
		out.println("Lab Chapter 9 - #7  LetterRemover    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		LetterRemover obj = new LetterRemover("I am Sam I am", 'a');
		out.println(obj.toString());
		out.println();
		
		obj.setRemover("ssssssssxssssesssssesss", 's');
		out.println(obj.toString());
		out.println();
		
		obj.setRemover("qwertyqwertyqwerty", 'a');
		out.println(obj.toString());
		out.println();
		
		obj.setRemover("abababababa", 'b');
		out.println(obj.toString());
		out.println();
		
		obj.setRemover("abaababababa", 'x');
		out.println(obj.toString());
		out.println();
											
	}  // end marker for method main
	
	
} // end marker for class 