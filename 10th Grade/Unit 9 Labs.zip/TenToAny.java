//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -
//EXTRA CREDIT
import static java.lang.System.*;

public class TenToAny
{
   private int base10;
   private int newBase;



	// add a constructor





	// add a setter method



	public String getNewNum()
	{
		String newNum="";
		
		// convert base10 number into the newBase
		
		
		
		return newNum;
	}



	// add a toString method	
	
	
	
	
	
}