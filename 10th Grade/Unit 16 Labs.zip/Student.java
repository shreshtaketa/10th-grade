
import java.util.*;

// FIND ALL OF THE FINISH ME comments
// and add the necessary code

public class Student
{
	String name;
	String id;
	String age;
	ArrayList <Integer> grades;	
	
	public Student(String theName, String theId, String theAge,
	               ArrayList<Integer> theGrades)
	{
		name = theName;
		
		grades = theGrades;
	 	
	 	id = theId;
	 	
	 	age = theAge;              
	}	
	
	
	public String getName()
	{
	 	// FINISH ME
				
		return name;  // replace me
	}

	public String getId()
	{
	 	// FINISH ME

		return id;  // replace me
	}

	public String getAge()
	{
	 	// FINISH ME

		return age;  // replace me
	}
	
	
	// finds the sum of grades
	public int getSum()
	{
		// FINISH ME
		
		int sum = 0;
		
		for (int i = 0; i < grades.size(); i++)
		{
			sum = sum + grades.get(i);
		}
			
		return sum; // replace me		
	}
	
	
	// finds the average of grades
	public double getAverage()
	{
		// FINISH ME
		double average = 0; 
		int total = 0;
		
		for (int i = 0; i < grades.size(); i++)
		{
			total = total + grades.get(i);
		}
		
		average = (double) total/(grades.size());
		
		return average; // replace me		
	}
	

	// finds the higest grade of grades
	public int getHighestGrade()
	{
		// FINISH ME
		int largestvalue = 0;
		
		for (int i = 0; i < grades.size(); i++)
		{
			if (grades.get(i)>largestvalue)
				largestvalue = grades.get(i);
		}
		
		return largestvalue;  // replace me		
	}
	
	
	// finds the lowest grade of grades
	public int getLowestGrade()
	{
		// FINISH ME
		
		int smallestvalue = getHighestGrade();
		
		for (int i = 0; i < grades.size(); i++)
		{
			if (grades.get(i)<smallestvalue)
				smallestvalue = grades.get(i);
		}
		
		return smallestvalue; // replace me		
	}

	
	// finds the difference of the highest and lowest grade
	public int getRange()
	{
		// FINISH ME
		int range = getHighestGrade()-getLowestGrade();
		return range;  // replace me		
	}

	
	// finds the number of val grades found in grades
	// for example if val is 100, it would count the
	//     number of times 100 appears in the list grades
	public int getCountOf(int val)
	{
		// FINISH ME
		int count = 0;
		
		for (int i = 0; i < grades.size(); i++)
		{
			if (grades.get(i)==val)
				count++;
		}
		
		return count;  // replace me		
	}


	// finds the number of grades greater than or equal to val
	public int getNumGTE(int val)
	{
		// FINISH ME
		int count = 0;
		
		for (int i = 0; i < grades.size(); i++)
		{
			if (grades.get(i)>=val)
				count++;
		}
		
		return count;  // replace me		
	}

	// finds the number of grades less than val
	public int getNumLT(int val)
	{
		// FINISH ME
		
		int count = 0;
		
		for (int i = 0; i < grades.size(); i++)
		{
			if (grades.get(i)<val)
				count++;
		}
		
		return count;  // replace me		
	}

	public String getGradeList()
	{
		String output = "";
		
		// FINISH ME
		// get a list of all of the grades separated with " "
		for (int i=0;  i<grades.size();  i++)
		{
			  output += grades.get(i) + " ";
		}	
			
		return output;
	}
	
	
}  // end of class Student



