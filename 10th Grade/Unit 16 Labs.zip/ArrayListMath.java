
import java.util.*;

// FIND ALL OF THE FINISH ME comments

public class ArrayListMath
{
	
	// FINISH ME
	public static int getSum(ArrayList<Integer> list)
	{
		int sum = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			sum = sum + list.get(i);
		}
			
		return sum;
	}
	
	
	
	// FINISH ME
	// PRECONDITION: list.size() is greater than 0
	public static double getAverage(ArrayList<Integer> list)
	{
		double average = 0; 
		int total = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			total = total + list.get(i);
		}
		
		average = (double) total/(list.size());
		
		return average;
	}
	
	
	
	// FINISH ME
	public static int getLargestValue(ArrayList<Integer> list)
	{
		int largestvalue = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			if (list.get(i)>largestvalue)
				largestvalue = list.get(i);
		}
		
		return largestvalue;
	}



	// FINISH ME
	public static int getSmallestValue(ArrayList<Integer> list)
	{
		int smallestvalue = getLargestValue(list);
		
		for (int i = 0; i < list.size(); i++)
		{
			if (list.get(i)<smallestvalue)
				smallestvalue = list.get(i);
		}
		
		return smallestvalue;

	}



	// FINISH ME
	public static int getNumberOfEvens(ArrayList<Integer> list)
	{
		int count = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			if (list.get(i)%2==0)
				count++;
		}
		
		return count;

	}



	// FINISH ME
	public static int getNumberOfOdds(ArrayList<Integer> list)
	{
		int count = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			if (list.get(i)%2==1)
				count++;
		}
		
		return count;

	}



	// FINISH ME
	// get the number of numbers greater than or equal to the parameter number
	public static int getNumberOfNumbersGTE(ArrayList<Integer> list, int number)
	{
		int count = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			if (list.get(i)>=number)
				count++;
		}
		
		return count;

	}



	// FINISH ME
	// get the number of numbers less than the parameter number
	public static int getNumberOfNumbersLT(ArrayList<Integer> list, int number)
	{
		int count = 0;
		
		for (int i = 0; i < list.size(); i++)
		{
			if (list.get(i)<number)
				count++;
		}
		
		return count;

	}
	
}


