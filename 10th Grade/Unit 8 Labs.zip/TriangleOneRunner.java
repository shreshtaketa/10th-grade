//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/30/18
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 8 - #4  TriangleOne    2018

// Uses files TriangleOneRunner.java and TriangleOne.java


public class TriangleOneRunner
{
	public static void main ( String[] args )
	{
		out.println("Lab Chapter 8 - #4  TriangleOne    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		

		
		
		
		// STEP 1: **************************************************
		// create a TriangleOne object and pass it the String "hippo"
		
		TriangleOne obj = new TriangleOne("hippo");
		
		
		
		// STEP 2: **************************************************
		// call the print() method of your TriangleOne object to print out the Triangle
		
		obj.print();
		System.out.println();
		System.out.println();
		
		
		
		
		// add more test cases
		// modify or change the word inside your TriangleOne object
		// DO NOT CREATE A NEW TriangleOne OBJECT (YOU ALREADY HAVE ONE)
		// call the TriangleOne object's setWord() method and pass it your new word
		
		obj.setWord("abcd");
		// and now print it
		obj.print();
		System.out.println();
		System.out.println();



		// add more test cases
		
		obj.setWord("it");
		obj.print();
		System.out.println();
		System.out.println();
		
		obj.setWord("a");
		obj.print();
		System.out.println();
		System.out.println();
		
		obj.setWord("chicken");
		obj.print();
		System.out.println();
		System.out.println();
		
				
	}
}