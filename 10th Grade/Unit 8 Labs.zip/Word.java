//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/30/18
//Class -
//Lab  -

import static java.lang.System.*;

public class Word
{
	private String word;



	public Word()
	{
		word = "";
	}



	public Word(String s)
	{
		word = s;
	}



	public void setString(String s)
	{
		word = s;
	}



	// get the first character of word
	public char getFirstChar()
	{
		return word.charAt(0);
	}



	// get the last character of word
	public char getLastChar()
	{
		return word.charAt(word.length()-1);
	}



	public String getBackWards()
	{
		String back="";
		
		// add a loop to get each character of word and 
		// join it (concatenate) onto back
		// back = back + word.charAt(?);
		
		for (int a = word.length()-1; a >= 0; a--)
		{
			back = back + word.charAt(a);
		}
		
		
		return back;
	}



 	public String toString()
 	{
 		// return the value of your instance variable word
 		return word; // replace me
	}
}