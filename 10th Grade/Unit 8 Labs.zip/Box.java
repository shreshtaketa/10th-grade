//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/28/18
//Class -
//Lab  -

import static java.lang.System.*;

public class Box
{
	// instance variable
	private String word;



	// default constructor
	// SAME NAME AS THE CLASS and no return type
	public Box()
	{
		word = "";
		// initialize word to the empty string ""	
	}



	// initializer constructor 
	// SAME NAME AS THE CLASS and no return type
	// String variable s is created and receives a beginning value 
	//    to store in our instance variable word
	public Box(String s)
	{
		word = s;
	} 


	// modifier or setter method
	// String variable s is created and receives a new value 
	//    to store in our instance variable word
	public void setWord(String s)
	{
			word = s;
	} 


	public void print( )
	{		
		// you will need a loop here
		// the loop should run word.length() times
		// each time through your loop you will print the value of word
		
		for (int count  = 0;  count  < word.length();  count++)
		{
			   // print out your word (use println, not print)
			   System.out.println(word);
		}
		
		
		// after the loop add 2 blank lines
		
		System.out.println();
		System.out.println();
		
		
	}
}