//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/3/18
//Class -
//Lab  -

import static java.lang.System.*;

public class Factorial
{
	private int number;



	public Factorial()
	{
		number = 0;
	}



	public Factorial(int num)
	{
		number = num;
	}



	public void setNum(int num)
	{
		number = num;
	}



	public int getNumber()
	{
		return number;
	}



	public long getFactorial( )
	{
		long factorial=1;


		// use a for loop 
		// loop from number downto 2
		//    each time through the the loop
		//      factorial = ? * loop variable; 

		for (int a = number; a >= 2; a--)
		{
			factorial = factorial * a;
		}

		return factorial;
	}



	public String toString()
	{
		// this has been done for you
		return "factorial of " + getNumber() + " is "+ getFactorial()+"\n";
	}
}