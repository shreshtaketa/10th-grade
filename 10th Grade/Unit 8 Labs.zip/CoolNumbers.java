//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/28/18
//Class -
//Lab  -

import static java.lang.System.*;

public class CoolNumbers 
{
	/*
	  * method isCoolNumber will return true if
	  *	num % 3 - 6 all have a remainder of 1
	  * it will return false otherwise
	*/
	public static boolean isCoolNumber( int num )
	{
		 // you will not need a loop for this
		 // think about an if statement 
		 if (num % 3 == 1 && num % 4 ==1 && num % 5 == 1 && num % 6 == 1 )
		     return true;
		 
		 
		 return false;
	}
	
	
	
	/*
	   * method countCoolNumbers will return the count
	   * of the coolNumbers between 6 and stop
	*/
	public static int countCoolNumbers( int stop )
	{
		// STEP 1:
		// you will need a variable to keep track of how many
		// cool numbers you have found
		
		int count = 0;
		
		
		// STEP 2:
		// you will need a loop to solve this problem
		// your loop control variable should start at 6,
		// be less than or equal to stop, and increment by 1 each time
		
		// 
		
		for (int num = 6;  num <= stop;  num++)
		{
			   // STEP 3: 
			   // each time through this loop
			   // you should call isCoolNumber and send it (pass it) your num
			   // if it returns true, then add 1 to your count variable
			   if (isCoolNumber(num)==true)
			   	count = count + 1;
			   	
		
		}
		
		// STEP 3:
		// you should return the number of cool numbers that you found
		
		return count;  // change me
	}
	
	
}