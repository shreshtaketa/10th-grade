//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/7/18
//Class -
//Lab  -

import static java.lang.System.*;


// THIS LAB IS EXTRA CREDIT

// Lab Chapter 8 - #11  GCD    2018

// Uses files GCDRunner.java and GCD.java


public class GCDRunner
{
	public static void main ( String[] args )
	{
		out.println("Lab Chapter 8 - #11 (EXTRA CREDIT)  GCD    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		
		// add test cases	
		
		GCD obj = new GCD (5,25);
		out.println(obj.toString());
		
		obj.setNums(4,400);
		out.println(obj.toString());
		
		obj.setNums(8,80);
		out.println(obj.toString());
		
		obj.setNums(15,45);
		out.println(obj.toString());
		
		obj.setNums(9,9);
		out.println(obj.toString());
		
		obj.setNums(3,543);
		out.println(obj.toString());
		
			
	}
}