//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/3/18
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 8 - #8  Factorial    2018

// Uses files FactorialRunner.java and Factorial.java


public class FactorialRunner
{
	public static void main ( String[] args )
	{
		out.println("Lab Chapter 8 - #8  Factorial    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		// STEP 1: **************************************************
		// create a Factorial object and pass it 5
		//     this will store 5 inside the object 
		
		Factorial obj = new Factorial(5);
		

		// STEP 2: **************************************************
		// print out what the toString() method of obj returns
		
		out.println(obj.toString());
		
		
		
		
		
		// add more cases
		
		obj.setNum(4);
		out.println(obj.toString());
		
		obj.setNum(8);
		out.println(obj.toString());
		
		obj.setNum(15);
		out.println(obj.toString());
		
		obj.setNum(6);
		out.println(obj.toString());
		
		obj.setNum(9);
		out.println(obj.toString());
		
		obj.setNum(3);
		out.println(obj.toString());
		
	}
}