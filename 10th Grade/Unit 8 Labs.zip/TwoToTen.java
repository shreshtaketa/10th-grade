//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -
//This lab is EXTRA CREDIT

import static java.lang.System.*;

public class TwoToTen
{
	private String binary;

	public TwoToTen()
	{
	}

	public TwoToTen(String bin)
	{
	}

	public void setTwo(String bin)
	{
	}

	public long getBaseTen( )
	{
		long ten=0;
		return ten;
	}

	public String toString()
	{
		return "";
	}
}