//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/28/18
//Class -
//Lab  -

import static java.lang.System.*;

// Lab Chapter 8 - #2  Box    2018

// Uses files BoxRunner.java and Box.java


public class BoxRunner
{
	public static void main ( String[] args )
	{
		out.println("Lab Chapter 8 - #2  Box    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		

		
		
		// STEP 1: **************************************************
		// create a Box object and pass it the String "hippo"
		
		Box obj = new Box ("hippo");
		
		
		
		// STEP 2: **************************************************
		// call the print() method of your Box object to print out the box
		
		obj.print();
		
		
		// add more test cases
		// modify or change the word inside your Box object
		// DO NOT CREATE A NEW Box OBJECT (YOU ALREADY HAVE ONE)
		// call the Box object's setWord() method and pass it your new word
		
		obj.setWord("abcd");
		obj.print();


		// add more test cases
		
		obj.setWord("it");
		obj.print();

		obj.setWord("a");
		obj.print();
		
		obj.setWord("chicken");
		obj.print();


	}
}