//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 12/7/2018
//Class -
//Lab  -

import static java.lang.System.*;


// THIS LAB IS EXTRA CREDIT

// Lab Chapter 8 - #10  TwoToTen    2018

// Uses files TwoToTenRunner.java and TwoToTen.java


public class TwoToTenRunner
{
	public static void main ( String[] args )
	{

		out.println("Lab Chapter 8 - #10 (EXTRA CREDIT)  TwoToTen    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		

		// add test cases
		
		
		
		
		
					
	}
}