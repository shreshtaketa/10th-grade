//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/28/18
//Class -
//Lab  - 

import static java.lang.System.*;

// Lab Chapter 8 - #3  VowelCounter    2018

// Uses files VowelCounterRunner.java and VowelCounter.java


public class VowelCounterRunner
{
	public static void main ( String[] args )
	{
		out.println("Lab Chapter 8 - #3  VowelCounter    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		

		
		// this has been done for you
		System.out.println( VowelCounter.getNumberString("abcdef") );
		System.out.println( VowelCounter.getNumberString("hhhhhhh") );
		System.out.println( VowelCounter.getNumberString("aaaaaaa") );		
		System.out.println( VowelCounter.getNumberString("catpigdatrathogbogfrogmoosegeese") );
		System.out.println( VowelCounter.getNumberString("hhhhhhh1234356HHHHDH") );
		System.out.println( VowelCounter.getNumberString("AEIOUaeiou87878alkjdaslwlejrlajflawjkflwj") );
		System.out.println( VowelCounter.getNumberString("") );
		System.out.println( VowelCounter.getNumberString("x") );
		System.out.println( VowelCounter.getNumberString("e") );
		
	}
}


