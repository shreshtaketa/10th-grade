//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/28/18
//Class -
//Lab  - 

import static java.lang.System.*;

public class VowelCounter
{
	public static String getNumberString( String s)
	{
		// you will receive a String called s with the data
		
		
		// STEP 1:
		// you will need to create an int variable for your count
		//    it should be set to 0
		
		int count = 0;
		
		// STEP 2:
		// you will need to create a new String variable (not s) to hold the output
		//    it should be set to the empty String to start  ""
		
		String output = "";
		
		// STEP 3:
		// you will need to loop through the String s and look at each character
		
		for (int i= 0;  i < s.length();  i++)
		{
			  // each time through the loop you need to get the character at the i position
			  char ch = s.charAt(i);
			  
			  // you will now need an if else statement to see if the character is a vowel
			  //    or you may want to use a switch statement
			  
			  if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U')
			  {
			  		
			  		
			  		// concatenate your count to your output string
			  		output = output + "" + count;
			  		
			  		// add 1 to your count
			  		
			  		count++;
			  		
			  		// see if your count == 10, and if so, set it to 0
			  		if (count == 10)
			  			count = 0;
			  }
			  else
			  {
			  			// concatenate your character ch to your output string
			  			output = output + "" + ch;
			  }
			  
		 }
		
		return output;  // return the new output String that you created 
	}
}


