//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/2/2018
//Class -
//Lab  - 

public class CubeRunner
{
	public static void main( String[] args )
   {
   		System.out.println("Lab Cube #4 - 2018");
   		System.out.println();
   		System.out.println("My name is Shreshta Keta");
   		System.out.println();
   		System.out.println();

		Cube test = new Cube();

	 	test.setSide(112);
	 	test.calculateSurfaceArea();
	 	test.print();

	 	//add more test cases
	 	
	 	test.setSide(4);
	 	test.calculateSurfaceArea();
	 	test.print();
	 	
	 	test.setSide(33);
	 	test.calculateSurfaceArea();
	 	test.print();
	 	
	 	test.setSide(50);
	 	test.calculateSurfaceArea();
	 	test.print();
	 	
	 	test.setSide(5);
	 	test.calculateSurfaceArea();
	 	test.print();
	 	
	 	test.setSide(19);
	 	test.calculateSurfaceArea();
	 	test.print();
	 
	 	
	}
}