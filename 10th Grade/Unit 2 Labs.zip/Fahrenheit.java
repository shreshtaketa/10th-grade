//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/3/2018
//Class -
//Lab  - 

public class Fahrenheit
{
	private double fahrenheit;

	public void setFahrenheit(double fahren)
	{
		fahrenheit = fahren;
	}

	public double getCelsius()
	{
		//add code to convert fahrenheit to celsius
		double celsius = (fahrenheit-32.0)*(5.0/9.0);

		return celsius;
	}

	public void print()
	{
		//modify this println to look like the word doc. Include a call to getCelsius()
		// as part of your println
		
		System.out.println(fahrenheit + " degrees Fahrenheit == " + getCelsius() + " degrees Celsius ");
		System.out.println();
		
	}
}