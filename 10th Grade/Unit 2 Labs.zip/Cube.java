//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/2/1018
//Class -
//Lab  - 

public class Cube
{
	private int side;
	private int surfaceArea;

	public void setSide(int s)
	{
		side = s;
	}

	public void calculateSurfaceArea( )
	{
		surfaceArea = 6*(side*side);
	}

	public void print( )
	{
		System.out.println("The surface area is :: " + surfaceArea);
		System.out.println();
	}
}