//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date -10/2/2018
//Class -
//Lab  - 

public class Circle
{
	private double radius;
	private double area;

	public void setRadius(double rad)
	{
		radius = rad;
	}

	public void calculateArea( )
	{
		area = (3.14159)*radius*radius;
	}

	public void print( )
	{
		System.out.println("The area is :: " + area);
		System.out.println();
	}
}