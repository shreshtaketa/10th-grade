//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/2/2018
//Class -
//Lab  - 

public class CircleRunner
{
	public static void main( String[] args )
   {
	
   		System.out.println("Lab Circle #5 - 2018");
   		System.out.println();
   		System.out.println("My name is Shreshta Keta");
   		System.out.println();
   		System.out.println();
   		//add test cases
   		
   		Circle test = new Circle();
   		
   		test.setRadius(7.5);
   		test.calculateArea();
   		test.print();
   		
   		test.setRadius(10);
   		test.calculateArea();
   		test.print();
   		
   		test.setRadius(72.534);
   		test.calculateArea();
   		test.print();
   		
   		test.setRadius(55);
   		test.calculateArea();
   		test.print();
   		
   		test.setRadius(101);
   		test.calculateArea();
   		test.print();
   		
   		test.setRadius(99.952);
   		test.calculateArea();
   		test.print();
   		
   		
   		
   		// see CubeRunner.java for help
		
	}
}