                                      //� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/3/2018
//Class -
//Lab  - This is an extra credit lab worth 110 points

public class FahrenheitRunner
{
	public static void main( String[] args )
	{
		//add test cases
   		System.out.println("Lab Fahrenheit #7 Extra Credit - 2018");
   		System.out.println();
   		System.out.println("My name is Shreshta Keta");
   		System.out.println();
   		System.out.println();
		
		Fahrenheit test = new Fahrenheit();
		
		test.setFahrenheit(98.6);
		test.getCelsius();
		test.print();
		
		test.setFahrenheit(52.30);
		test.getCelsius();
		test.print();
		
		test.setFahrenheit(82.45);
		test.getCelsius();
		test.print();
		
		test.setFahrenheit(75.00);
		test.getCelsius();
		test.print();
		
		test.setFahrenheit(100.00);
		test.getCelsius();
		test.print();		
	}
}