//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/1/2018
//Class -
//Lab  - 

public class RectangleRunner
{
	public static void main( String[] args )
	{
   		System.out.println("Lab Rectangle #2 - 2018");
   		System.out.println();
   		System.out.println("My name is Shreshta Keta");
   		System.out.println();
   		System.out.println();
   		
		Rectangle test = new Rectangle();
		
		test.setLengthWidth(2,6);
		test.calculatePerimeter( );
		test.print();

		test.setLengthWidth(12,5);
		test.calculatePerimeter( );
		test.print();


		// add more test cases
		
		test.setLengthWidth(131,75);
		test.calculatePerimeter( );
		test.print();
		
		test.setLengthWidth(20,25);
		test.calculatePerimeter( );
		test.print();
		
		test.setLengthWidth(9,256);
		test.calculatePerimeter( );
		test.print();
		
		test.setLengthWidth(36,72);
		test.calculatePerimeter( );
		test.print();
		
	}
}