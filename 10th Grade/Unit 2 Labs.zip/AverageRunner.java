//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date -10/1/2018
//Class -
//Lab  - 

public class AverageRunner
{
	public static void main( String[] args )
   {
   		System.out.println("Lab Average #3 - 2018");
   		System.out.println();
   		System.out.println("My name is Shreshta Keta");
   		System.out.println();
   		System.out.println();
   		
   		
 		// create an Average object (new it!)
 		Average avg = new Average();
 		
 		// call the setNums method and pass it 2 values
 		avg.setNums(5,5);
 		
 		// call the average method which will calculate the average
 		avg.average();
 		
 		// call the print method to print the info
 		avg.print();
 		
 		
 		// ********************************************
 		// now add more test cases
 		
 		avg.setNums(90, 100.0);
 		avg.average();
 		avg.print();
 		
 		avg.setNums(100, 85.8);
 		avg.average();
 		avg.print();
 		
 		avg.setNums(-100,55);
 		avg.average();
 		avg.print();
 		
 		avg.setNums(15236,5642);
 		avg.average();
 		avg.print();
 		
 		avg.setNums(1000,555);
 		avg.average();
 		avg.print();
 		
 		
	}
}