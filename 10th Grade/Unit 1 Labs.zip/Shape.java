//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 09/27/18
//Class - AP Computer Science
//Lab  - Shape

import java.awt.Color;
import java.awt.Graphics;

public class Shape
{
   //instance variables
	private int xPos;
	private int yPos;
	private int width;
	private int height;
	private Color color;

   public Shape(int x, int y, int wid, int ht, Color col)
   {
		xPos = x;
		yPos = y;
		
		// finish this constructor 
		// by assigning values to your instance variables
		
		width = wid;
		height = ht;
		color = col;
		
   }


   public void draw(Graphics window)
   {
      window.setColor(Color.RED);
      window.drawString("Shreshta Keta     APCS 2018",10,40);
      
    //  window.setColor(color);
    //  window.fillRect(xPos, yPos, width, height);

      // draw whatever you want
      // You will need to use Graphics routines like
      //    window.drawRect(...);
      //    window.drawOval(...);
      //    window.drawLine(...);
      //    window.drawString(...);
      //    and any others
      // The ... indicates that you need to supply the parameters
      //    ^
      
      window.setColor(Color.BLUE);
      window.drawOval(xPos, yPos, width, height);
      window.setColor(color);
      window.fillOval(xPos+1, yPos+1, width-2, height-2);
      
   }




   public String toString()
   {
   	return xPos+" "+yPos+" "+width+" "+height+" "+color;
   }
}