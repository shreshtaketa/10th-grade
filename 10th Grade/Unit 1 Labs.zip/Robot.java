//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 09/21/18
//Class - AP Computer Science
//Lab  - Robot

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Canvas;

class Robot extends Canvas
{
   public Robot()    //constructor method - sets up the class
   {
      setSize(800,600);
      setBackground(Color.WHITE);   	
      setVisible(true);
   }

   public void paint( Graphics window )
   {
   	  window.setColor(Color.RED);
   	  window.drawString("Shreshta Keta     APCS 2018",10,40);

      window.setColor(Color.BLUE);

      window.drawString("Robot LAB ", 10, 75 );

      // call head method and pass it window
  
      head(window);
      
      // call other methods and pass it window
      
      upperBody(window);
      lowerBody(window);
      
   }

   public void head( Graphics window )
   {
      	window.setColor(Color.YELLOW);

      	window.fillOval(300, 100, 200, 100);

		// add more code here
		
		window.setColor(Color.GREEN);
		window.fillOval(360, 130, 20, 20);
		window.fillOval(425, 130, 20, 20);
		
		window.setColor(Color.BLACK);
		window.fillOval(394, 157, 20, 10);
		
		window.setColor(Color.RED);
		window.drawArc(370, 165, 65, 25, 180, 180);
		
   }

   public void upperBody( Graphics window )
   {

		// add more code here
		
		window.setColor(Color.YELLOW);
		window.drawRect(350, 225, 110, 60);
		
		window.setColor(Color.BLUE);
		window.fillRect(351, 226, 109, 59);
		
		window.setColor(Color.BLACK);
		window.drawLine(350, 225, 275, 175);
		window.drawLine(460, 225, 535, 175);
		
		
   }

   public void lowerBody( Graphics window )
   {

		// add more code here
		
		window.setColor(Color.YELLOW);
		window.drawRect(350, 300, 110, 60);
		
		window.setColor(Color.GRAY);
		window.fillRect(351, 301, 109, 59);
		
		window.setColor(Color.BLACK);
		window.drawLine(350, 360, 275, 410);
		window.drawLine(460, 360, 510, 410);

   }
}