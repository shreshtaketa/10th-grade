//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 08/18/18
//Class - AP Computer Science
//Lab  - Stars and Stripes Lab

import static java.lang.System.*;

public class StarsRunner
{
   public static void main(String args[])
   {
      // instantiate a StarsAndStripes object (new it!)
      // StarsAndStripes stars = new ??????????();
      StarsAndStripes stars = new StarsAndStripes();
      
      // call the methods needed to make the patterns on the word document
      // stars.?????();

      stars.printASmallBox();
      stars.printTwoBlankLines();
      stars.printABigBox();
      
   }
}