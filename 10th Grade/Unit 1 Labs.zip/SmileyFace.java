//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 09/20/18
//Class - AP Computer Science
//Lab  - Smiley Face

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Canvas;

public class SmileyFace extends Canvas
{
   public SmileyFace()    //constructor - sets up the class
   {
      setSize(800,600);
      setBackground(Color.WHITE);
      setVisible(true);
   }

   public void paint( Graphics window )
   {
      smileyFace(window);
   }

   public void smileyFace( Graphics window )
   {
   	  window.setColor(Color.RED);
   	  window.drawString("Shreshta Keta APCS 2018", 10,40);
      window.setColor(Color.BLUE);
      window.drawString("SMILEY FACE LAB ", 10, 75);

      window.setColor(Color.YELLOW);
      window.fillOval( 210, 100, 400, 400 );

		//add more code here
		window.setColor(Color.BLACK);
		window.fillOval ( 320, 190, 40, 40);
  		window.setColor (Color.BLACK);
		window.fillOval ( 450, 190, 40, 40 );
		window.setColor (Color.GREEN);
		window.fillOval ( 390, 290, 25, 25 );
		window.setColor (Color.RED);
		window.drawArc ( 300, 350, 210, 40, 180, 180);
}
}