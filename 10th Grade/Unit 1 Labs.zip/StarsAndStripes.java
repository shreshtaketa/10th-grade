//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 08/18/18
//Class - AP Computer Science
//Lab  - Stars and Stripes

// the static import statement allows us to use
// out.println(...);  and out.print(...); 
// instead of using  System.out.println(...);

import static java.lang.System.*;

public class StarsAndStripes
{
	
   // this is your default constructor
   // it gets called when you create the class in the
   // main program	
   public StarsAndStripes()
   {
   	  out.println("Shreshta Keta       APCS 2018");
   	  out.println();
   	  out.println();
      out.println("StarsAndStripes");
      printTwoBlankLines();
   }


   public void printTwentyStars()
   {
   	// write a println statement that prints 20 stars *
   	out.println("********************");
   }

   public void printTwentyDashes()
   {
   	// write a println statement that prints 20 dashes -
   	out.println("--------------------");
   }

   public void printTwoBlankLines()
   {
   	// write 2 println statements that print nothing 
   	out.println();
   	out.println();
   }
   
   public void printASmallBox()
   {
   	// print the small box
   	// call the methods above
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();

   		
   }
 
   public void printABigBox()
   { 	
   	// print the big box
   	// call the methods above
	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   	printTwentyStars();
   	printTwentyDashes();
   } 

   	  
}  // end of class StarsAndStripes
