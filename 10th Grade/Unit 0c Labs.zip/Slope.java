//Slope.java
// always put your name in the comments
//Shreshta Keta
//09/11/18


import java.util.Scanner;

public class Slope {
        
    
    public static void main(String[] args) 
    {
        System.out.println("Shreshta   Keta");
        System.out.println();
        System.out.println("Slope.java");
        System.out.println("APCS 2018");
        System.out.println();
        System.out.println();
        
        
        // create a Scanner object so that
        //    we can read in data from the keyboard
        Scanner scan = new Scanner (System.in);
        
        double x1;  // the x value of the first point
        double y1;  // the y value of the first point
        
        double x2;  // the x value of the second point
        double y2;  // the y value of the second point
        
        double slope;  // holds the slope of the line
        
        
        System.out.println("Slope of a Line");
        System.out.println();
        System.out.println();
        
        // here we prompt the user to enter the x value for the first point 
        // and then we read it in
        System.out.print("Enter x1 ");
        x1 = scan.nextDouble();
        
        // prompt the user to enter y1 
        // and then read it in

		System.out.print("Enter y1 ");
        y1 = scan.nextDouble();
      
        System.out.println();
        

        // prompt the user to enter x2 
        // and then read it in

		System.out.print("Enter x2 ");
		x2 = scan.nextDouble();

        // prompt the user to enter y2 
        // and then read it in
        
        System.out.print("Enter y2 ");
        y2 = scan.nextDouble();
        
        System.out.println();
        
        
        // calculate the slope using the correct formula
        slope = (y2-y1)/(x2-x1);
        
        // now print out "The slope of the line is" concatenated with the slope
        // See the image in Lab0c folder for sample output

        System.out.println("The slope of the line is " + slope);
        System.out.println();
        System.out.println();
                
    } // end of method main
    
}  // end of class Slope


