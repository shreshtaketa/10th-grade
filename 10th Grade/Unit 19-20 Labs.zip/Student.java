
import static java.lang.System.*; 
import java.util.ArrayList;


// implements Comparable means that we have
// to write a compareTo() method that will receive
// an object.

// All classes extend the Object class by default

// NOTICE: a Student  IS A  Person
// We get all of Person and whatever we want to add

class Student extends Person implements Comparable
{
	// add an instance variable called 
	// grades, which is an ArrayList<Integer>

	private ArrayList<Integer> grades;

	// write an init constructor
	// you should have parameters to receive
	//    the name, id, and an ArrayList<Integer> reference
	//    in that order
	// call super(name, id);  to initialize the Person part 
	// the call to super MUST be the first line of code
	// what do you need to do to grades?

	public Student(String n, String i, ArrayList<Integer> g)
	{
		super(n,i);
		grades = g;
	}



	// *******  MODIFIERS (setter methods)
	
	// write a setGrades() method

	public void setGrades(ArrayList<Integer> g)
	{
		grades = g;
	}

	// *******  ACCESSORS (getter methods)
	

	// write a getGrades() method

	public ArrayList<Integer> getGrades()
	{
		return grades;
	}

	// write a method to find the sum of the grades
	
	public int getSum()	
	{
		int sum = 0;
		
		for (int i = 0; i < grades.size(); i++)
			sum = sum + grades.get(i);
			
		return sum;
	}

	// write a method to find the average of the grades
	
	public double getAverage()
	{
		double average = getSum()/grades.size();
		
		return average;
	}

	// we will override the equals method which is defined
	// in the super class
	// two Student objects will be considered equal if
	// their names are the same
	
	public boolean equals( Object obj)
	{
		Student other = (Student) obj; // cast obj as a Student

		if (name.equals(other.name))
			return true;

		return false;
	}


	// this method was declared in the 
	// comparable interface!  We must write it
	// compare this student's average to the 
	//    other student's average
	public int compareTo(Object obj)
	{
		Student other = (Student) obj; // cast obj as a Student
		
		
		// we should return -1 if this Student is less 
		// than the other Student

		if (getAverage()<other.getAverage())
			return -1;

		// we should return 1 if this Student is greater 
		// than the other Student

		if (getAverage()>other.getAverage())
			return 1;
		
		// we should return 0 if this Student is equal to 
		// the other Student

		return 0;
	}

	// write a toString() method that returns
	// the Student's name followed by a space 
	// followed by the Student's id, followed by
	// the Student's list of grades
	// call super.toString() to get the Person part
	//    and then grades.toString() to get the grades
	
	public String toString()
	{
		return super.toString() + " " + grades.toString();
	}
	
	
	
	
}