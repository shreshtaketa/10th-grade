//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 2/8/19
//Class - 
//Lab  -

// Lab Chapter 14 - #5  Histogram    2019

// Uses files HistogramRunner.java and Histogram.java

// HINT:  Look at sample arrays to understand what you need to do in your code.
//		  DRAW PICTURES and walk through what you need to do.
//        If you don't know what needs to be done, you certainly cannot give
//        instructions to the computer to tell it what to do.


public class HistogramRunner
{
	public static void main(String args[])
	{
		System.out.println("Lab Chapter 14 - #5  Histogram    2019");
		System.out.println();
		System.out.println();
		
		// ***** fill in your name
		System.out.println("My name is Shreshta Keta");
		System.out.println();		
		System.out.println();		

		
		// Histogram 1 ********************************************************************
		// create a new Histogram object
		Histogram histogramObjectReference = new Histogram("1 5 3 4 5 5 5 4 3 2 5 5 5 3");
		System.out.println(histogramObjectReference);
		System.out.println();





		// Histogram 2 ********************************************************************
		// call the modifier method (setter method) to change the data inside the object
		histogramObjectReference.setHistogramArray("2 3 4 5 6 7 8 9 0 2 3 5 6 8 8 8 9 4 5");
		
		// call the toString() method of the object and print the results
		System.out.println(histogramObjectReference.toString());
		System.out.println();





		// Histogram 3 ********************************************************************
		// call the modifier method (setter method) to change the data inside the object
		histogramObjectReference.setHistogramArray("2 3 4 5 6 7 8 2 0 2 3 5 6 8 8 8 9 4 5");
		
		// call the toString() method of the object and print the results
		System.out.println(histogramObjectReference.toString());		
		System.out.println();



		
		System.out.println();
		System.out.println();
	}
}