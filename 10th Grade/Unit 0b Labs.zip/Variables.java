//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 08/31/18
//Class - AP Computer Science
//Lab  - Variables

public class Variables
{
	public static void main ( String[] args )
	{
		// define 1 variable as a byte and assign it 127 (this is done for you)
		byte byteOne = 127;		

		// define 1 variable as a short and assign it 1270 (this is done for you)
		short shortOne = 1270;	
			
		

		// define all other variables
		int intOne= 90877;
		long longOne= 999999999;
		float floatOne= 38.5678f;
		double  doubleOne= 923.234;
		char charOne= 'A';
		boolean booleanOne= true;
		String stringOne= "hello world";

		//output your information here
		System.out.println("/////////////////////////////////");
		System.out.println("*Shreshta Keta          08/31/18*");
		System.out.println("*                               *");
		System.out.println("*        Integer Types          *");
		System.out.println("*                               *");
		System.out.println("*8 bit - byteOne = " + byteOne + "\t\t*");
		System.out.println("*16 bit - shortOne = " + shortOne + "\t*");
		System.out.println("*32 bit - intOne = " + intOne + "\t*");
		System.out.println("*64 bit - longOne = " + longOne + "\t*");
		System.out.println("*                               *");
        System.out.println("*          REAL TYPES           *");
        System.out.println("*                               *");
        System.out.println("*32 bit - floatOne = " + floatOne + "\t*");
        System.out.println("*64 bit - doubleOne = " + doubleOne + "\t*");
        System.out.println("*                               *");
        System.out.println("*      OTHER INTEGER TYPES      *");
        System.out.println("*                               *");
        System.out.println("*16 bit - charOne = " + charOne + "\t\t*");
        System.out.println("*                               *");
        System.out.println("*          OTHER TYPES          *");
        System.out.println("*                               *");
        System.out.println("*booleanOne = " + booleanOne + "\t\t*");
        System.out.println("*stringOne= " + stringOne + "\t\t*");
        System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        


		// add more println statements to print out all other info









	}
}