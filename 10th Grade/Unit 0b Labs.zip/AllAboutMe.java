// AllAboutMe.java
//
// This program practices declaring, assigning and ouputing variables
// of different data types.
//

public class AllAboutMe
{
	public static void main (String args[])
	{
		System.out.println("APCS 2018  Shreshta Keta                 09/04/2018 ");
		/* Declare variables with the following data types. A description
		 * of the variable's purpose should help you choose a meaningful 
		 * identifier.  These are declarations only!
		 *
		 * byte - your age
		 * int - # of text messages you sent in August
		 * float - your shoe size
		 * double - I couldn't think of anything! Make something up! (Must have decimal!)
		 *
		 * char - your gender
		 * boolean - you love mexican food
		 * String - favorite color
		 * String - favorite song   */
	
		// I've done the first two for you. You do the rest(see comments above)
	
		
		byte myAge;
		int  numTextMessages;
		float shoeSize;
		double tennisYears;
		char gender;
		boolean mexicanFood;
		String favoriteColor;
		String favoriteSong;
			
		
		// Now assign your variables some value.
		// See my example. Feel free to change the values.
		
		
		myAge = 14;
		numTextMessages = 42;
		shoeSize = 10.5f;
		tennisYears = 4.5;
		gender = 'F';
		mexicanFood = true;
		favoriteColor = "aqua";
		favoriteSong = "Eastside";
		
		// At this point in the program, using println statements,
		// output your mailing label. It should look something like this...
		// 
		//		Ms. Minnie Mouse
		//		1234 Walt Disney Way
		//		Hollywood, CA  90210
		//
		//   
		//  
		
		
		// print out your mailing label here
		System.out.println();
		System.out.println("      Shreshta Keta      ");
		System.out.println("      4008 Hambletonian  ");
		System.out.println("      Austin, TX 78746   ");
		System.out.println();


		// Now, print out the values of all of your variables
		// See how I included a meaningful message concatenated with your variable
		
		System.out.println(" My age is -----> " + myAge);
		System.out.println();
		System.out.println(" Text messages sent -----> " + numTextMessages);
		System.out.println();
		System.out.println(" My shoe size is -----> " + shoeSize);
		System.out.println();
		System.out.println(" Years of playing tennis -----> " + tennisYears);
		System.out.println();
		System.out.println(" My gender is -----> " + gender);
		System.out.println();
		System.out.println(" I like Mexican Food -----> " + mexicanFood);
		System.out.println();
		System.out.println(" My favorite color is -----> " + favoriteColor);
		System.out.println();
		System.out.println(" My favorite song is -----> " + favoriteSong);
		System.out.println();
		
		// add more println statements here
			
			
			
			
			
		System.out.println(" \nTHE END !!!  ");
		System.out.println("APCS 2018");
		System.out.println();
		System.out.println();	
		
		
	}
}