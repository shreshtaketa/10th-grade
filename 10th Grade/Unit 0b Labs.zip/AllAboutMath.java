// AllAboutMath.java
//Name Shreshta Keta
//Date 09/05/2018
//Period 4
// This program practices declaring, assigning and ouputing variables
// of different data types.
//

public class AllAboutMath
{
	public static void main (String args[])
	{
		System.out.println("APCS 2018  name Shreshta Keta                 date 09/05/2018 ");
		
		/* notice that /* is the start of a multiline comment
		 * Declare variables with the following data types. A description
		 * of the variable's purpose should help you choose a meaningful 
		 * identifier.  These are declarations only!

		 * String - Your name

		 * byte - your grade on homework 1
		 * byte - your grade on homework 2
		 * byte - your grade on homework 3
		 * byte - your grade on homework 4
		 * byte - your grade on test 1 (what you hope it will be)
		 * byte - your grade on test 2 (what you hope it will be)


		 * char - your letter grade on homework 1   90 or above = A   80-89 = B  70-79 = C   0-69 = F 
		 * char - your letter grade on homework 2
		 * char - your letter grade on homework 3
		 * char - your letter grade on homework 4
		 * char - your letter grade on test 1
		 * char - your letter grade on test 2

		 *
		 * skip a line before outputting this information
		 *
		 * float  - your average on the homework assignments (let the computer compute it!)
		 * Example: hwAvg = (hw1 + hw2 + hw3)/3f;
		 * float  - your average on the tests (let the computer compute it!)
		 * float  - your overall average (see formula below)
		 * overallAverage = homeworkAverage*0.3f + testAverage*0.7f;
		 *
		 * boolean - are you passing or failing?
		 *
		 * skip a line before outputting this information
		 * int - number of horizontal pixels on your monitor  (1280)
		 * int - number of vertical pixels on your monitor  (1024)
		 * double - the area of the monitor in square pixels (let the computer compute it!)
		*/
		
		// declare all of your variables here
		// I've done the first five for you... 
		
		String name;
		
		byte   gradeHW1;   // your grade on homework 1
		char   letterHW1;  // your letter grade on homework 1
		
		byte   gradeHW2;   // your grade on homework 2
		char   letterHW2;  // your letter grade on homework 2		
		
		// next declare 
		//    gradeHW3, letterHW3, gradeHW4, letterHW4, 
		//    gradeTest1, letterTest1, gradeTest2, letterTest2
		
		byte  gradeHW3;
		char  letterHW3;
		
		byte gradeHW4;
		char letterHW4;
		
		byte gradeTest1;
		char letterTest1;
		
		byte gradeTest2;
		char letterTest2;
		
		float hwAvg;
		float testAvg; 
		float overallAvg;
		
		boolean passing;
		
		int horizPixels;
		int vertPixels;
		double areaMonitor;
		
		// Now assign your variables some value here
		// Make up the grades. Do not use all 100's !
		// I've done the first five for you... 
		
		name = "Shreshta Keta";
		
		gradeHW1 = 100;
		letterHW1 = 'A';

		gradeHW2 = 80;
		letterHW2 = 'B';

		// next assign values to 
		//    gradeHW3, letterHW3, gradeHW4, letterHW4, 
		//    gradeTest1, letterTest1, gradeTest2, letterTest2

		gradeHW3 = 75;
		letterHW3 = 'C';
		
		gradeHW4 = 67;
		letterHW4 = 'F';
			
		gradeTest1 = 100;
		letterTest1 = 'A';
		
		gradeTest2 = 89; 
		letterTest2 = 'B';

		hwAvg = (gradeHW1 + gradeHW2 + gradeHW3 + gradeHW4)/3f; 
		testAvg = (gradeTest1 + gradeTest2)/2f;
		overallAvg = (hwAvg*0.3f + testAvg*0.7f);
		
		passing = true;
		
		horizPixels = 1280; 
		vertPixels = 1024;
		areaMonitor = (horizPixels * vertPixels);
		
		// At this point in the program, use println statements and
		// output your name, your four homework grades and the letter grade, ...
		// each line should have a description followed by the value of the variable
		// It should look something like this...
		// 
		//		 My name is -----> Julie Java (well, whatever your name is should go here)
		//		
		//		 Homework 1 numerical grade is 100  (don't print is100)
		//		 Homework 1 letter grade is A       (don't print isA)
		//
		// For example...
		
		System.out.println(" My name is -----> " + name);
		System.out.println();	
		System.out.println(" Homework 1 numerical grade is " + gradeHW1);
		System.out.println(" Homework 1 letter grade is    " + letterHW1);
		System.out.println();
		System.out.println(" Homework 2 numerical grade is " + gradeHW2);
		System.out.println(" Homework 2 letter grade is    " + letterHW2);
		// finish your printing below
		// separate each set of data with a blank line in the output
		// For instance: homework grades/ blank line/ test grades/ blank line/ averages/ blank line/ passing / blank line/ monitor infor
		
		System.out.println();
		System.out.println(" Homework 3 numerical grade is " + gradeHW3);
		System.out.println(" Homework 3 letter grade is    " + letterHW3);
		System.out.println();
		System.out.println(" Homework 4 numerical grade is " + gradeHW4);
		System.out.println(" Homework 4 letter grade is    " + letterHW4);
		System.out.println();
		System.out.println(" Test 1 numerical grade is " + gradeTest1);
		System.out.println(" Test 1 letter grade is    " + letterTest1);
		System.out.println();
		System.out.println(" Test 2 numerical grade is " + gradeTest2);
		System.out.println(" Test 2 letter grade is    " + letterTest2);
		System.out.println();
		System.out.println(" Homework Average is " +hwAvg);
		System.out.println(" Test Average is " +testAvg);
		System.out.println(" Overall Average is " + overallAvg);
		System.out.println(" Am I passing? " + passing);
		System.out.println();
		System.out.println(" Horizontal Pixels on the Monitor " + horizPixels);
		System.out.println(" Vertical Pixels on the Monitor " + vertPixels);
		System.out.println(" Area of Monitor " + areaMonitor);
		System.out.println();
		
		
		
		
		
		System.out.println();
		System.out.println();
		System.out.println("APCS 2018");
	}
}