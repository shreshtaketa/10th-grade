//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 3/12/19
//Class - 
//Lab  -

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.*;

// Lab Chapter Matrices - #2  TicTacToe    2019

// Uses files TicTacToeRunner.java && TicTacToe.java && LabTTT.dat

public class TicTacToeRunner
{
	public static void main( String args[] ) throws IOException
	{
		System.out.println("Lab Chapter Matrices - #2  TicTacToe    2019");
		System.out.println();
		System.out.println();
		
		// FINISH ME
		// ***** fill in your name
		System.out.println("My name is Shreshta Keta");
		System.out.println();		
		System.out.println();		


		Scanner file = new Scanner (new File("LabTTT.dat"));

		// we will read in the number of games
		int numberOfGames = file.nextInt();
		file.nextLine();
		
		// read in one game and determine the winner
		for (int i=1; i<=numberOfGames; i++)
		{
			// read in the game result 
			// the first three characters are for row 0, the next three for row 1, etc.
			String game = file.nextLine(); // something like XXXOOXXOO
			
			// instantiate a new TicTacToe object (new it!)
			
			TicTacToe match = new TicTacToe(game);
			
			// call your toString() method to print out the Tic Tac Toe board
			
			out.print(match.toString());
			
			// call your getWinner() method and print it
			
			out.println(match.getWinner());
			
			System.out.println();		
			System.out.println();
			
		}






	}
}



