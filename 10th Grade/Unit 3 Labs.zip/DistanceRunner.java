//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/11/2018
//Class -
//Lab  -

import java.util.Scanner; 
import static java.lang.System.*;
import static java.lang.Math.*;

public class DistanceRunner
{
	public static void main( String[] args )
	{
		// THIS PROBLEM IS EXTRA CREDIT
		// YOU WILL GET A 110/100 IF your program
		//     works properly
		
		// NOTE: Look back at previous labs for help
		//       Also, look at the word doc
		
		
 		System.out.println("My name is Shreshta Keta");
		System.out.println();
		System.out.println("#4 - Distance Extra Credit Lab 2018 version");
		System.out.println();
		System.out.println();
		
		Scanner one = new Scanner(System.in);
		out.print("Enter X1 :: ");
		int x1 = one.nextInt();
		out.print("Enter Y1 :: ");
		int y1 = one.nextInt();
		out.print("Enter X2 :: ");
		int x2 = one.nextInt();
		out.print("Enter Y2 :: ");
		int y2 = one.nextInt();
		
		Distance two = new Distance(x1,y1,x2,y2);
		two.calcDistance();
		two.print();
		

		// add more test cases 2018
		
		out.print("Enter X1 :: ");
		x1 = one.nextInt();
		out.print("Enter Y1 :: ");
		y1 = one.nextInt();
		out.print("Enter X2 :: ");
		x2 = one.nextInt();
		out.print("Enter Y2 :: ");
		y2 = one.nextInt();
		
		two.setCoordinates(x1, y1, x2, y2);
		two.calcDistance();
		two.print();
		
		
		
		out.print("Enter X1 :: ");
		x1 = one.nextInt();
		out.print("Enter Y1 :: ");
		y1 = one.nextInt();
		out.print("Enter X2 :: ");
		x2 = one.nextInt();
		out.print("Enter Y2 :: ");
		y2 = one.nextInt();
		
		two.setCoordinates(x1, y1, x2, y2);
		two.calcDistance();
		two.print();
	}
}