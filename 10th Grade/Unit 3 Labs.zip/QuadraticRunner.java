//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date -10/9/18
//Class -
//Lab  -

import java.util.Scanner; 
import static java.lang.System.*;
import static java.lang.Math.*;

public class QuadraticRunner
{
	public static void main( String[] args )
   {

 		System.out.println("My name is Shreshta Keta");
		System.out.println();
		System.out.println("#3 - Quadratic  2018 version");
		System.out.println();
		System.out.println();
		

		// create a Scanner object so that we can read in values
		//    from the user
		// look at previous programs if you do not remember how to do this
  		Scanner keyboard = new Scanner(in);
  	
  	
   		// add 3 test cases
   		
   		
   		// ***** here is a guide for the first case
   		
   		
   		// ***** STEP 1: GET THE INPUT VALUES FROM THE USER for a,b, and c
   		
   		// prompt the user to enter a value for a
   		
   		// then read it in using your Scanner reference variable and assign it to variable a   	
		
   		// prompt the user to enter a value for b
   		
   		// then read it in using your Scanner reference variable and assign it to variable b 	

   		// prompt the user to enter a value for c
   		
   		// then read it in using your Scanner reference variable and assign it to variable c
   		
   		out.print("Enter a value for a :: ");
   		int a = keyboard.nextInt();
   		
   		out.print("Enter a value for b :: ");
   		int b = keyboard.nextInt();
   		
   		out.print("Enter a value for c :: ");
   		int c = keyboard.nextInt();
   		
   		// ***** STEP 2: CREATE (INSTANTIATE) a Quadratic object 
   		
		Quadratic quad = new Quadratic(a, b, c);
		  		
   		// ***** STEP 3: Call the calcRoots method 
   		
		quad.calcRoots();   
   		  	
   		// ***** STEP 4: Call the print method 
   		
		quad.print();   
		
		
		
		out.print("Enter a value for a :: ");
   		a = keyboard.nextInt();
   		
   		out.print("Enter a value for b :: ");
   		b = keyboard.nextInt();
   		
   		out.print("Enter a value for c :: ");
   		c = keyboard.nextInt();
   		
   		quad.setEquation(a, b, c);
   		quad.calcRoots();
   		quad.print();
   		
   		
   		
   		out.print("Enter a value for a :: ");
   		a = keyboard.nextInt();
   		
   		out.print("Enter a value for b :: ");
   		b = keyboard.nextInt();
   		
   		out.print("Enter a value for c :: ");
   		c = keyboard.nextInt();
   		
   		quad.setEquation(a, b, c);
   		quad.calcRoots();
   		quad.print();
		
	}
}