//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 10/5/2018
//Class -
//Lab  -

import java.util.Scanner; 
import java.lang.Math.*;

public class TriangleRunner  //this class is used to test class Triangle
{
	public static void main( String[] args )
	{
		System.out.println("My name is Shreshta Keta");
		System.out.println();
		System.out.println("#1 - Triangle 2018 version");
		System.out.println();
		System.out.println();
		
		// this creates a new Scanner object so that
		// we can read data that the user enters
		Scanner keyboard = new Scanner(System.in);


		//ask for user input (prompt the user)
		System.out.print("Enter side A ::  ");
		// this reads in the data and converts it to a 32 bit int
		int a = keyboard.nextInt();  

		System.out.print("Enter side B ::  ");
		int b = keyboard.nextInt();

		System.out.print("Enter side C ::  ");
		int c = keyboard.nextInt();


		// we create a new Triangle object
		// and send to the constructor the values
		// of our varibles a, b, and c
		Triangle test = new Triangle(a, b, c);
		test.calcPerimeter();
		test.calcArea();
		test.print();


		//ask for user input - round 2
		System.out.print("Enter side A ::  ");
		a = keyboard.nextInt();

		System.out.print("Enter side B ::  ");
		b = keyboard.nextInt();

		System.out.print("Enter side C ::  ");
		c = keyboard.nextInt();


		test.setSides(a,b,c);
		test.calcPerimeter();
		test.calcArea();
		test.print();


		// ****************  add one more input section

	System.out.print("Enter side A ::  ");
		a = keyboard.nextInt();

		System.out.print("Enter side B ::  ");
		b = keyboard.nextInt();

		System.out.print("Enter side C ::  ");
		c = keyboard.nextInt();


		test.setSides(a,b,c);
		test.calcPerimeter();
		test.calcArea();
		test.print();



	}
}