//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 2/22/2019
//Class - 
//Extra Credit Lab  -

import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import static java.lang.System.*;

// Lab Chapter 15 - #4  NumberSearch    2019 EXTRA CREDIT

// Uses files NumberSearchRunner.java and NumberSearch.java

public class NumberSearchRunner
{
	public static void main( String args[] ) throws IOException
	{
		System.out.println("Lab Chapter 15 - #4 (Extra Credit)  NumberSearch    2019");
		System.out.println();
		System.out.println();
		
		// ***** fill in your name
		System.out.println("My name is Shreshta Keta");
		System.out.println();		
		System.out.println();		


		int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1};
		int find = 5;

			
		out.println("Original Array = " + Arrays.toString(array));
			
		array = NumberSearch.sortArray(array);
		
		out.println("Sorted Array   = " + Arrays.toString(array));
		out.println();
		out.println("The next largest value after " + find + " is " + NumberSearch.getNextLargest(array, find));
		out.println();
		out.println();

		// add more cases
			
		int [] arraytwo = {10,30,20,40,50,15};
		int findtwo = 12;

			
		out.println("Original Array = " + Arrays.toString(arraytwo));
			
		arraytwo = NumberSearch.sortArray(arraytwo);
		
		out.println("Sorted Array   = " + Arrays.toString(arraytwo));
		out.println();
		out.println("The next largest value after " + findtwo + " is " + NumberSearch.getNextLargest(arraytwo, findtwo));
		out.println();
		out.println();



		int [] arraythree = {3,4,5,6,8,9,10,11,2,3,4,65};
		int findthree = 25;

			
		out.println("Original Array = " + Arrays.toString(arraythree));
			
		arraythree = NumberSearch.sortArray(arraythree);
		
		out.println("Sorted Array   = " + Arrays.toString(arraythree));
		out.println();
		out.println("The next largest value after " + findthree + " is " + NumberSearch.getNextLargest(arraythree, findthree));
		out.println();
		out.println();
		
		
		
		int [] arrayfour = {100,110,1000,25000,65535};
		int findfour = 32767;

			
		out.println("Original Array = " + Arrays.toString(arrayfour));
			
		array = NumberSearch.sortArray(arrayfour);
		
		out.println("Sorted Array   = " + Arrays.toString(array));
		out.println();
		out.println("The next largest value after " + findfour + " is " + NumberSearch.getNextLargest(arrayfour, findfour));
		out.println();
		out.println();
	}
}



