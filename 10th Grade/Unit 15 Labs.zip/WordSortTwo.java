//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Extra Credit Lab  - 

import java.util.Arrays;
import java.util.Scanner;
import static java.lang.System.*;

public class WordSortTwo
{
	private String[] wordRay;

	public WordSortTwo(String sentence)
	{
	}

	public void sort()
	{
	}

	public String toString()
	{
		String output="";
		return output+"\n\n";
	}
}