//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 2/25/19
//Class - 
//Lab  -
//Extra Credit Lab 
import java.util.Arrays;
import java.util.Scanner;
import java.util.Collections;
import static java.lang.System.*;

public class FancyWords
{
	private String[] wordRay;

	public FancyWords(String sentence)
	{

		wordRay = sentence.split(" "); //splits sentence into an array with words in separate places
		
	}

	public String toString()
	{
		
		String output="";
		int wordStarter = wordRay.length-1;
		int letterStarter = wordRay[wordStarter].length()-1;
		
		for (int letter = letterStarter; letter >= 0; letter--)//letter to print
		{
			for (int word = wordStarter; word >=0; word--)//word that we are on
			{
				if (letter==letterStarter)
				{
				output = output + wordRay[word].substring(letter);
				}
			/*	else if (letter==null)
				{
					output = output + " ";
				}*/
				else if (letter!=letterStarter)
				{
				output = output + wordRay[word].substring(letter,letter+1);
				}
			}
			output = output + "\n";
		}
		
		return output+"\n\n";
	}
}