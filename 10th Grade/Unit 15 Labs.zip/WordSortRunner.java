//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 2/11/19
//Class -
//Lab  -

import java.util.Arrays;
import static java.lang.System.*; 


// Lab Chapter 15 - #1  WordSort    2019

// Uses files WordSortRunner.java and WordSort.java


public class WordSortRunner
{
	public static void main(String args[])
	{
		System.out.println("Lab Chapter 15 - #1  WordSort    2019");
		System.out.println();
		System.out.println();
		
		// ***** fill in your name
		System.out.println("My name is Shreshta Keta");
		System.out.println();		
		System.out.println();		




		// first we create a WordSort object
		// and pass (send) to it the list of words "abc ABC 12321 fred alexander"
		WordSort  myWordSortReference = new WordSort("abc ABC 12321 fred alexander");
		

		// now we print the return value of our toString() method
		System.out.println(myWordSortReference.toString());
		
		
		// add more test cases
		
		myWordSortReference.setList("a zebra friendly acrobatics 435 TONER PRinTeR");
		System.out.println(myWordSortReference.toString());
		
		myWordSortReference.setList("b x 4 r s y $");
		System.out.println(myWordSortReference.toString());
		
		myWordSortReference.setList("123 ABC abc 034 cat dog sally sue bob 2a2");
		System.out.println(myWordSortReference.toString());
		
	}
}