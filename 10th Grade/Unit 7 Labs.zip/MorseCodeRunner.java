//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/15/18
//Class -
//Lab  -

import static java.lang.System.*; 

// Lab Chapter 7 - #4  MorseCode    2018

// Uses files MorseCodeRunner.java and MorseCode.java

// HINT:  Look back at previous programs that you have
//        written to help you. 
//        Draw a picture of your MorseCode object.
//        Look at your doc file to see the correct output.

public class MorseCodeRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 7 - #4  MorseCode    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		// There is no Scanner object in this lab. No input.
		
		// Step 1:
		// Construct a new MorseCode object and send
		// the value of 'A' to the constructor
		//    make sure that your reference variable
		//    refers to a MorseCode object 
	    MorseCode obj = new MorseCode('A');
		
		
		// Step 2:
		// use out.println(...) to print out the morse code
		//    you will need to call your MorseCode object's 
		//    getMorseCode() method
		// look at your doc file to see the correct output
		out.println(obj.getMorseCode());
		
		
		// Step 3:
		// use out.println(...) to print out the morse code message
		//    you will need to call your MorseCode object's 
		//    toString() method
		// look at your doc file to see the correct output
		out.println(obj.toString());		


		// Step 4: print a blank line
		// out.?????????
		out.println();
		

		obj.setChar('B');
		out.println(obj.getMorseCode());
		out.println(obj.toString());	
		out.println();
		
		obj.setChar('3');
		out.println(obj.getMorseCode());
		out.println(obj.toString());	
		out.println();
		
		obj.setChar('Z');
		out.println(obj.getMorseCode());
		out.println(obj.toString());	
		out.println();
		
		obj.setChar('8');
		out.println(obj.getMorseCode());
		out.println(obj.toString());	
		out.println();
		
		obj.setChar('F');
		out.println(obj.getMorseCode());
		out.println(obj.toString());	
		out.println();
		
		obj.setChar('0');
		out.println(obj.getMorseCode());
		out.println(obj.toString());	
		out.println();
		
	}
}