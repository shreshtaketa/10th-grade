//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/27/2018
//Class -
//Lab  -


// ************************
// This lab is extra credit 2018
// ************************

public class MouseButtonTesterRunner
{ 
	public static void main(String[] args)
	{
		out.println("Lab Chapter 7 - #6  MouseButtonTester   Extra Credit 2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		
		MouseButtonTester prog = new MouseButtonTester();
	}
}