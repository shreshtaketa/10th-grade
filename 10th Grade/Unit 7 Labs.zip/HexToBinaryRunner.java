//� A+ Computer Science  -  www.apluscompsci.com
//Name - Shreshta Keta
//Date - 11/14/18
//Class -
//Lab  -

import static java.lang.System.*; 
import java.util.Scanner;

// Lab Chapter 7 - #2  HexToBinary    2018

// Uses files HexToBinaryRunner.java and HexToBinary.java

// HINT:  Look back at previous programs that you have
//        written to help you. 
//        Draw a picture of your HexToBinary object.
//        Look at your doc file to see the correct output.


public class HexToBinaryRunner
{
	public static void main( String args[] )
	{
		out.println("Lab Chapter 7 - #2  HexToBinary    2018");
		out.println();
		out.println();
		
		// ***** fill in your name
		out.println("My name is Shreshta Keta");
		out.println();		
		out.println();		
		
		
		// Step 1:
		// Construct a Scanner object to read in the hex character
		// make sure that variable keyboard refers to a Scanner object
		Scanner keyboard = new Scanner (System.in);
		
		
		// Step 2:
		// prompt the user to enter a hex character
		// look at the doc file for an example
		out.print("Enter a letter :: ");
		
		
		// Step 3:
		// read in the hex character that the user enters and store it
		// look back at the CharacterAnalyzerRunner in Labs 5 for an example
		char hexChar = keyboard.next().charAt(0);
		
		
		
		// Step 4:
		// Construct a new HexToBinary object and send
		// the value of hexChar (your input) to the constructor
		//    make sure that your reference variable
		//    refers to a HexToBinary object 
	    HexToBinary obj = new HexToBinary(hexChar);
		
		
		// Step 5:
		// use out.println(...) to print out the results
		//    you will need to call your HexToBinary object's toString() method
		// look at your doc file to see the correct output
		out.print(obj.toString());
		
		
		// Step 6: print a blank line
		// out.?????????
		out.println();
		


		out.print("Enter a letter :: ");
		hexChar = keyboard.next().charAt(0);
	    obj.setHex(hexChar);
	    out.println(obj.toString());
		out.println();
		
		out.print("Enter a letter :: ");
		hexChar = keyboard.next().charAt(0);
	    obj.setHex(hexChar);
	    out.println(obj.toString());
		out.println();
				
		out.print("Enter a letter :: ");
		hexChar = keyboard.next().charAt(0);
	    obj.setHex(hexChar);
	    out.println(obj.toString());
		out.println();
		
		out.print("Enter a letter :: ");
		hexChar = keyboard.next().charAt(0);
	    obj.setHex(hexChar);
	    out.println(obj.toString());
		out.println();
		
		out.print("Enter a letter :: ");
		hexChar = keyboard.next().charAt(0);
	    obj.setHex(hexChar);
	    out.println(obj.toString());
		out.println();

		out.print("Enter a letter :: ");
		hexChar = keyboard.next().charAt(0);
	    obj.setHex(hexChar);
		out.println(obj.toString());
		out.println();
	

	}
}